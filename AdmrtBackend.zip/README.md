# AdMrt Main Backend

A Django project built as the main backend of [AdMrt](https://admrt.com)