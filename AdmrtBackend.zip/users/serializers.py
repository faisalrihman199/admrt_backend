from rest_framework import serializers
from .models import (
    SpaceHost,
    Advertiser,
    AdvertiserProduct,
    Topic,
    SocialMedia,
    Portfolio,
    AdSpaceForSpaceHost,
)
from core.models import User

# Profile Serializers
class AdSpaceForSpaceHostSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdSpaceForSpaceHost
        fields = ['id', 'space_type', 'file', 'url']


class SocialMediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = SocialMedia
        fields = ['id', 'social_media', 'url']


# class ProductImageUploadSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ProductImageUploadFragment
#         fields = ['id', 'file']


from rest_framework import serializers
from .models import AdvertiserProduct

from rest_framework import serializers
from .models import AdvertiserProduct
import json

class ProductSerializer(serializers.ModelSerializer):
    topics = serializers.CharField(write_only=True, required=False, allow_blank=True)  # Optional field

    class Meta:
        model = AdvertiserProduct
        fields = ['id', 'name', 'description', 'image1', 'image2', 'image3', 'productType', 'topics']

    def create(self, validated_data):
        topics_data = validated_data.pop('topics', '')  # Get the comma-separated string, or empty string if not provided
        if topics_data:
            # Convert the comma-separated string into a list
            topics_list = [topic.strip() for topic in topics_data.split(',')]
        else:
            topics_list = []  # If no topics provided, set it as an empty list
        product = AdvertiserProduct.objects.create(**validated_data)
        # Store topics as a stringified list (JSON format)
        product.topics = json.dumps(topics_list)
        product.save()
        return product

    def update(self, instance, validated_data):
        topics_data = validated_data.pop('topics', '')  # Get the comma-separated string, or empty string if not provided
        if topics_data:
            # Convert the comma-separated string into a list
            topics_list = [topic.strip() for topic in topics_data.split(',')]
        else:
            topics_list = []  # If no topics provided, set it as an empty list
        instance = super().update(instance, validated_data)
        # Update the topics as a stringified list
        instance.topics = json.dumps(topics_list)
        instance.save()
        return instance

    def to_representation(self, instance):
        # When returning data, convert the stringified list back to a Python list
        representation = super().to_representation(instance)
        representation['topics'] = json.loads(instance.topics) if instance.topics else []  # Convert stringified list back to list
        return representation



class AdvertiserSerializer(serializers.ModelSerializer):
    products = ProductSerializer(many=True, read_only=True)
    socials = SocialMediaSerializer(many=True, read_only=True)
    joined = serializers.DateTimeField(source='user.date_joined', read_only=True)
    id = serializers.IntegerField(source='user.id', read_only=True)
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault()
    )
    user_role = serializers.CharField(source='user.user_role', read_only=True)
    full_name = serializers.CharField(source='user.full_name', read_only=True)

    class Meta:
        model = Advertiser
        fields = ['id', 'full_name', 'profile_image', 'banner_image', 'description', 'location', 'website', 'is_admin', 'joined', 'products', 'socials', 'user_role', 'user']


class TopicSerializer(serializers.ModelSerializer):
    class Meta:
        model = Topic
        fields = ['id', 'title']


# class PortfolioImageUploadSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = PortfolioImageUploadFragment
#         fields = ['id', 'file']
        

class PortfolioSerializer(serializers.ModelSerializer):
    # images = PortfolioImageUploadSerializer(many=True, read_only=True)
    class Meta:
        model = Portfolio
        fields = ['id', 'title', 'description', 'image1', 'image2', 'image3', 'youtube_url']


# class LanguageSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Language
#         fields = ['id', 'language']


class SpaceHostSerializer(serializers.ModelSerializer):
    topics = TopicSerializer(many=True, read_only=True)
    # languages = LanguageSerializer(many=True, read_only=True)
    portfolios = PortfolioSerializer(many=True, read_only=True)
    socials = SocialMediaSerializer(many=True, read_only=True)
    ad_spaces = AdSpaceForSpaceHostSerializer(many=True, read_only=True)
    joined = serializers.DateTimeField(source='user.date_joined', read_only=True)
    id = serializers.IntegerField(source='user.id', read_only=True)
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault()
    )
    user_role = serializers.CharField(source='user.user_role', read_only=True)
    full_name = serializers.CharField(source='user.full_name', read_only=True)
    
    class Meta:
        model = SpaceHost
        fields = ['id', 'full_name', 'profile_image', 'banner_image', 'description', 'location', 'website', 'is_admin', 'joined', 'long_term_service_availability', 'topics', 'languages', 'portfolios', 'socials', 'ad_spaces', 'user_role', 'user']


class AdvertiserProductCountSerializer(serializers.ModelSerializer):
    product_count = serializers.IntegerField()

    class Meta:
        model = User
        fields = ['id', 'full_name', 'product_count']